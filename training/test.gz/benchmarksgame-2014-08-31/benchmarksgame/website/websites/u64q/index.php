<?php 
header("HTTP/1.1 301 Moved Permanently");
header("Location: http://benchmarksgame.alioth.debian.org/");
exit;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>The Computer Language Benchmarks Game</title>
</head>
<body>
<h3><a href="http://benchmarksgame.alioth.debian.org/">The Computer Language Benchmarks Game</a></h3>
</body>
</html>
