<?php 
// Copyright (c) Isaac Gouy 2004

require_once('config.php'); 
require_once(LIB_PATH.'chart.php'); 

?>
