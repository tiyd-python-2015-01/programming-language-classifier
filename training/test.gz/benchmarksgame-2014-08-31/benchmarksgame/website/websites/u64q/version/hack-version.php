<p>HipHop VM 3.0.0-dev (rel)<br/>
Compiler: heads/master-0-g7fe20173f182c6f8363c3f1752da50aa16c674df<br/>
Repo schema: daaf94930cc75e7b0cb2b11779a1be66280a5b6c</p>
