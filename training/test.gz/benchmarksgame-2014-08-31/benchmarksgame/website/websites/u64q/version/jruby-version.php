<p>jruby 1.7.11 (1.9.3p392) 2014-02-24 86339bb on Java HotSpot(TM) 64-Bit Server VM 1.8.0-b132 +indy [linux-amd64]</p>
