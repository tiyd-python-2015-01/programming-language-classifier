<p>VisualWorks(R) 7.7 beta2 Nov 16 2009<br/>
[ 64-bit thapi ephemerons immutability ]</p>
