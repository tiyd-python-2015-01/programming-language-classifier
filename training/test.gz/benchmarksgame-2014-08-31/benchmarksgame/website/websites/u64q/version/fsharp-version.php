<p>F# Compiler for F# 3.1 (Open Source Edition)</p>
<p>Mono JIT compiler version 3.8.1 (master/db3eb16 Wed Aug 13 12:36:50 PDT 2014)<br/>
	LLVM:          yes(3.4svn-mono-mono/e656cac)<br/>
	GC:            sgen
</p>
