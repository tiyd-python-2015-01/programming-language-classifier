<p>ruby 1.8.7 (2008-08-11 patchlevel 72) [x86_64-linux]</p>
