<p>Welcome to Racket v6.0.</p>
