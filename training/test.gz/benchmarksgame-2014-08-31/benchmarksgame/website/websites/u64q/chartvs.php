<?php 
// Copyright (c) Isaac Gouy 2005

require_once('config.php'); 
require_once(LIB_PATH.'chartvs.php'); 
?>

