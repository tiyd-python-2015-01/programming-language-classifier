<?php
// Copyright (c) Isaac Gouy 2004-2009

require_once('config.php'); 
require_once(LIB_PATH.'chartscore.php');
?>

