<?php
// Copyright (c) Isaac Gouy 2009-2012
ob_start('ob_gzhandler');
require_once('config.php'); 
$T = 'all'; $L = 'python3'; $metaRobots = '';
require_once(LIB_PATH.'compare.php'); 
?>
