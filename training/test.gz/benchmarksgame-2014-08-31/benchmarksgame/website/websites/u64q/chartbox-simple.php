<?php
// Copyright (c) Isaac Gouy 2011

require_once('config.php'); 
require_once(LIB_PATH.'chartbox-simple.php');
?>

