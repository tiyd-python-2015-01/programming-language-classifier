<?php
// Copyright (c) Isaac Gouy 2009
ob_start('ob_gzhandler');
require_once('config.php'); 
require_once(LIB_PATH.'summarydata.php');

?>

