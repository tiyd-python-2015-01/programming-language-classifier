<p>Erlang (BEAM) emulator version 5.6.2 [source] [64-bit] [smp:4] [async-threads:0] [hipe] [kernel-poll:false]</p>
