<p>JavaScript-C 1.8.0 pre-release 1 2007-10-03</p>
