<?php
// Copyright (c) Isaac Gouy 2013
ob_start('ob_gzhandler');
require_once('config.php'); 
$T = 'all'; $L = 'clojure'; $metaRobots = '';
$LinkRelCanonical = '<link rel="canonical" href="http://benchmarksgame.alioth.debian.org/u64q/clojure.php" />';
require_once(LIB_PATH.'compare.php');
?>
