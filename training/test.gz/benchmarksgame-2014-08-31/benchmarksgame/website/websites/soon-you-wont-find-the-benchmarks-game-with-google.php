<?php
// Copyright (c) Isaac Gouy 2013
ob_start('ob_gzhandler');
require_once('config.php'); 
$F = 'soon-you-wont-find-the-benchmarks-game-with-google'; $T = "Soon you won't find the Benchmarks Game with Google or any other search engine";
require_once(LIB_PATH.'miscfile.php');
?>
