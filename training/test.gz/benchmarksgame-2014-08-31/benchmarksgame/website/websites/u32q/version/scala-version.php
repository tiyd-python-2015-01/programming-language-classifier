<p>java version "1.8.0"<br/>
Java(TM) SE Runtime Environment (build 1.8.0-b132)<br/>
Java HotSpot(TM) Server VM (build 25.0-b70, mixed mode)
</p>
<p>Scala compiler version 2.10.3 -- Copyright 2002-2013, LAMP/EPFL</p>
