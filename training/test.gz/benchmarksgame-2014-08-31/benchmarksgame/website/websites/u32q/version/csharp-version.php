<p>Mono JIT compiler version 3.8.1 (master/0322d96 Wed Aug 13 11:49:57 PDT 2014)<br/>
	LLVM:          yes(3.4svn-mono-mono/e656cac)<br/>
	GC:            sgen
</p>
