<?php
// Copyright (c) Isaac Gouy 2014
ob_start('ob_gzhandler');
require_once('config.php'); 
$T = 'all'; $L = 'rust'; $metaRobots = '';
require_once(LIB_PATH.'comparetimes.php'); 
?>
