<p>(The benchmark rules say that the program "should use built-in line-oriented io", and that's exactly what this is, even though it's a bit unconventional.)</p>
