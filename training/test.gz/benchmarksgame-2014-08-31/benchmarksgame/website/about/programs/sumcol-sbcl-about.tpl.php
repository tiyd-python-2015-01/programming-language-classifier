<p><strong>NOT ACCEPTED:</strong> should use built-in line-oriented I/O functions rather than custom-code</p>
