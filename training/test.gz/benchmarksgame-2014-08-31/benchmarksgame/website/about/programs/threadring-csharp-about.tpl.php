<p><a href="http://research.microsoft.com/~birrell/papers/ThreadsCSharp.pdf">An Introduction to Programming with C# Threads (pdf)</a>.</p>
