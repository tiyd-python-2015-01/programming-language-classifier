<p>Compare to "Warmed" JVM timings using System.nanoTime() - see <a href="<?=CORE_SITE;?>help.php#java">Help: What about Java?</a></p>
