<p>Low memory use compared to other language implementations - because Free Pascal statically links programs by default, avoiding libc.</p>
