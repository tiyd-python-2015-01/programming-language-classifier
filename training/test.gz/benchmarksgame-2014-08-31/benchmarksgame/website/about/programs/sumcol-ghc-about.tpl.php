<p><strong>NOT ACCEPTED:</strong> should use built-in line-oriented I/O functions rather than custom-code</p>


<p><a href="http://www.cse.unsw.edu.au/~dons/papers/CLS07.html">Stream Fusion: From Lists to Streams to Nothing at All</a></p>
<pre>@unpublished{CLS07,
    author = {Duncan Coutts and Roman Leshchinskiy and Don Stewart},
    title  = {Stream Fusion: From Lists to Streams to Nothing at All},
    year   = 2007,
    month  = apr,
    note   = "Submitted for publication"
}</pre>

