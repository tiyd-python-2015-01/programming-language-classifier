<p><strong>Don't split pattern at |</strong></p>
