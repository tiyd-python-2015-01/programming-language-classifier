<p>For this to work on 32bit we have to set <tt>ulimit -s 100</tt></p>
