<p>See <a href="http://blog.chromium.org/2009/02/irregexp-google-chromes-new-regexp.html">"Irregexp, Google Chrome's New Regexp Implementation"</a></p>
