<p>Here CINT is only being used as a <b>C interpreter</b> but a CINT script can call compiled classes/functions and compiled code can make callbacks to CINT interpreted functions.</p>

