<?   // Copyright (c) Isaac Gouy 2004-2006 ?>
<h2>&nbsp;<?=$Title?></h2>
<pre><?=$Text?></pre>

