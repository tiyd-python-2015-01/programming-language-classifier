<?   // Copyright (c) Isaac Gouy 2004-2006 ?>

<p class="timestamp"><? printf('%s GMT', gmdate("d M Y, l, g:i a", $Changed)) ?></p>
<? include($MiscFile); ?>
