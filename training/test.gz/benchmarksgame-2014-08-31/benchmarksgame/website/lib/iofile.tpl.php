<?   // Copyright (c) Isaac Gouy 2004-2006 ?>
<?
printf('<p><span class="s">(Save Target As&#8230; Save Link As&#8230;)</span> <a href="%s" title="Save %s As&#8230;">%s</a></p>', $Download,$Title,$Title);   
?>
<h2><a href="#io" name="io">&nbsp;<?=$Title?></a></h2>
<pre><?=$Text?></pre>

